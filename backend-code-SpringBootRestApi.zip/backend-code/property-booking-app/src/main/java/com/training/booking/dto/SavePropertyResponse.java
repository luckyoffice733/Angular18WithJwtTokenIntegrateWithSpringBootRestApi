package com.training.booking.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SavePropertyResponse {

	private long propertyId;

	private String response;

}
