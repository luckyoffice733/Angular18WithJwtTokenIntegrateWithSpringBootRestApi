export class DashboardResponse {
    response?: string;
    totalProperty?: number;
    totalAvailableProperty?: number;
    totalBookedProperty?: number;
    latestAddedProperty?: any;
    latestBookedProperty?: any;
}
