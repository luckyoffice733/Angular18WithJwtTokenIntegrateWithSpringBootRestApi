 export interface PropertyResponse {
    propertyId: number;
    response: string;
  }
