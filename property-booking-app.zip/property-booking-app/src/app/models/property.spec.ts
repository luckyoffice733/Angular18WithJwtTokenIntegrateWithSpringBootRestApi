import { Property } from './property';

describe('Property', () => {
  it('should create an instance', () => {
    expect(new Property()).toBeTruthy();
  });
});
