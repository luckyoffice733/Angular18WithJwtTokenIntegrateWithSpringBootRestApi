export class SignupRequest {
    name?: string
    username?: string
    password?: string
    address?: string
    mobileno?: string
    age?: string
}
